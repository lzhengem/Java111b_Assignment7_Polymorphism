
 //*************************************************************************
 //Represent the Payable interface
 //	
 //  @author(s) Chien Lin, Lena Zheng, Qian Dong Li
 //*************************************************************************

 public interface Payable {
    public double pay();
 }